import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
import joblib

# 1. Carrega o CSV com os dados dos fragmentos
df = pd.read_csv("csv_compostosteste.csv")

# 2. Remove linhas com valores ausentes (opcional, dependendo da qualidade dos dados)
df.dropna(subset=["compound_name", "fragment_mz", "fragment_intensity"], inplace=True)

# 3. Codifica os nomes dos compostos como números (label encoding)
le = LabelEncoder()
df["compound_encoded"] = le.fit_transform(df["compound_name"])

# 4. Define as features (X) e o target (y)
X = df[["fragment_mz", "fragment_intensity"]]
y = df["compound_encoded"]

# 5. Divide em treino e teste
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 6. Cria e treina o modelo
clf = RandomForestClassifier(n_estimators=100, random_state=42)
clf.fit(X_train, y_train)

# 7. Avalia o modelo
y_pred = clf.predict(X_test)
print(classification_report(y_test, y_pred, target_names=le.classes_))

# 8. Salva o modelo e o codificador
joblib.dump(clf, "modelo.pkl")
joblib.dump(le, "label_encoder.pkl")

print("Modelo treinado e salvo como 'modelo.pkl'. Codificador salvo como 'label_encoder.pkl'")
