from app import app, db
from sqlalchemy import text

with app.app_context():
    db.session.execute(text("UPDATE alembic_version SET version_num = 'head'"))
    db.session.commit()
    print("Versão do Alembic corrigida com sucesso!")
