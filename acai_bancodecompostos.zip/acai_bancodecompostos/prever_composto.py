import pandas as pd
import joblib

# Carregar modelo e scaler
model = joblib.load('modelo_composto.pkl')
scaler = joblib.load('scaler.pkl')

# Definir novos dados
novos_dados = pd.DataFrame([
    [1, 100, 287.0548, 50.0]
], columns=['analytics_id', 'fragment_id', 'fragment_mz', 'fragment_intensity'])

# Aplicar transformação
novos_dados_scaled = scaler.transform(novos_dados)

# Fazer predição
previsao = model.predict(novos_dados_scaled)

print("Composto previsto:", previsao[0])
