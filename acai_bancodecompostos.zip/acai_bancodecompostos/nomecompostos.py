import pandas as pd
import sqlite3

# Conectar ao banco de dados
conn = sqlite3.connect('compounds.db')

# Carregar fragmentos já exportados
df_fragmentos = pd.read_csv('fragments_export.csv')

# Carregar nomes dos compostos
df_nomes = pd.read_sql_query(
    "SELECT compound_id, compound AS compound_name FROM tbl_compound",
    conn
)

# Fazer merge entre fragmentos e nomes
df_final = df_fragmentos.merge(df_nomes, on='compound_id', how='left')

# Salvar novo CSV com nomes incluídos
df_final.to_csv('fragments_export_com_nomes.csv', index=False)

# Salvar dicionário separado
df_nomes.drop_duplicates().to_csv('dicionario_nomes.csv', index=False)

print("Arquivos 'fragments_export_com_nomes.csv' e 'dicionario_nomes.csv' foram exportados com sucesso.")

