import pandas as pd

# Configurações
CAMINHO_CSV = 'compostos_treino.csv'
TOLERANCIA = 50.0  # Faixa de tolerância em Da (ex: ±50 Da)

# Função para buscar compostos pela massa
def buscar_compostos(massa_alvo, tolerancia=TOLERANCIA):
    # Carrega o CSV
    df = pd.read_csv(CAMINHO_CSV, sep=';')
    
    # Converte a coluna para float
    df['molecular_mass'] = pd.to_numeric(df['molecular_mass'], errors='coerce')

    # Remove linhas com valores inválidos
    df = df.dropna(subset=['molecular_mass'])
    
    # Filtra os compostos dentro da faixa de massa
    df_filtrado = df[
        (df['molecular_mass'] >= massa_alvo - tolerancia) &
        (df['molecular_mass'] <= massa_alvo + tolerancia)
    ].copy()
    
    # Calcula a diferença absoluta para ordenar
    df_filtrado['diferenca'] = (df_filtrado['molecular_mass'] - massa_alvo).abs()
    df_ordenado = df_filtrado.sort_values(by='diferenca')

    return df_ordenado[['compound_name', 'molecular_mass', 'diferenca']]

# Exemplo de uso
if __name__ == '__main__':
    massa = float(input("Digite a massa molecular: "))
    resultados = buscar_compostos(massa)

    if resultados.empty:
        print("Nenhum composto encontrado dentro da faixa de tolerância.")
    else:
        print("\nCompostos encontrados:")
        print(resultados.to_string(index=False))
