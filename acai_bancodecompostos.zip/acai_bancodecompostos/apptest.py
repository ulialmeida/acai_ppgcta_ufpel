from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///C:/Users/almei/PycharmProjects/banco_compostos/compounds.db'
db = SQLAlchemy(app)

# Defina seus modelos SQLAlchemy para as tabelas do banco de dados
class Compound(db.Model):
    __tablename__ = 'tbl_compound' 
    compound_id = db.Column(db.Integer, primary_key=True)
    compound = db.Column(db.String(255))
    molecular_formula = db.Column(db.String(255))
    molecular_mass = db.Column(db.Float)
    
class Matrix(db.Model):
    __tablename__ = 'tbl_matrixes'
    matrix_id = db.Column(db.Integer, primary_key=True)
    organism = db.Column(db.String(255))
    plant_tissue = db.Column(db.String(255))

# Rotas para exibição e interação com os dados
@app.route('/')
def index():
    compounds = Compound.query.all()
    return render_template('index.html', compounds=compounds)

@app.route('/add_compound', methods=['POST'])
def add_compound():
    compound = request.form['compound']
    molecular_formula = request.form['molecular_formula']
    molecular_mass = request.form['molecular_mass']
    
    new_compound = Compound(compound=compound, molecular_formula=molecular_formula, molecular_mass=molecular_mass)
    db.session.add(new_compound)
    db.session.commit()
    
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)