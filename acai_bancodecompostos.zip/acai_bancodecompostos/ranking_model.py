from difflib import SequenceMatcher

def similaridade_formula(f1, f2):
    """Retorna similaridade entre duas fórmulas moleculares como um valor entre 0 e 1"""
    if not f1 or not f2:
        return 0.0
    return SequenceMatcher(None, f1, f2).ratio()

def rankear_por_score(compostos, formula_alvo=None, mz_alvo=None, intensidade_alvo=None):
    """Rankeia compostos com base em similaridade com entrada"""
    resultados = []

    for c in compostos:
        score = 0

        # Similaridade da fórmula molecular (quanto mais semelhante, menor o score)
        if formula_alvo:
            sim_formula = similaridade_formula(c.get('formula'), formula_alvo)
            score += (1 - sim_formula) * 100  # Peso ajustável

        # Distância m/z
        if mz_alvo is not None:
            dist_mz = abs(c.get('m_z') - mz_alvo)
            score += dist_mz

        # Distância intensidade
        if intensidade_alvo is not None:
            dist_int = abs(c.get('intensidade', 0) - intensidade_alvo)
            score += dist_int

        c['score'] = score
        resultados.append(c)

    return sorted(resultados, key=lambda x: x['score'])

