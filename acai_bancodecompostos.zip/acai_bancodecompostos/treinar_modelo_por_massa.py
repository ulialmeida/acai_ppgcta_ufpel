import pandas as pd
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report

ARQUIVO_CSV = 'compostos_treino.csv'
MODELO_SAIDA = 'modelo_massa_composto.pkl'

# ✅ Carregar dados com separador correto
df = pd.read_csv(ARQUIVO_CSV, sep=';')
print(df.columns)

# Filtrar apenas linhas com massa e nome
df = df[df['molecular_mass'].notnull() & df['compound_name'].notnull()]

# === 2. Preparar dados ===
X = df[['molecular_mass']]
y = df['compound_name']

# Codificar o nome dos compostos como números
label_encoder = LabelEncoder()
y_encoded = label_encoder.fit_transform(y)

# Dividir entre treino e teste
X_train, X_test, y_train, y_test = train_test_split(X, y_encoded, test_size=0.2, random_state=42)

# === 3. Treinar modelo ===
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# === 4. Avaliação ===
y_pred = model.predict(X_test)
print("Relatório de classificação:\n")

import numpy as np

# Recupera apenas as classes presentes no conjunto de teste
labels_test = np.unique(y_test)
target_names_test = label_encoder.inverse_transform(labels_test)

# Gera o relatório com as labels corretas
print(classification_report(y_test, y_pred, labels=labels_test, target_names=target_names_test))


# === 5. Salvar modelo e encoder ===
joblib.dump(model, MODELO_SAIDA)
joblib.dump(label_encoder, 'label_encoder.pkl')

print(f"\nModelo salvo como '{MODELO_SAIDA}' e label encoder como 'label_encoder.pkl'")
