import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
import joblib
import matplotlib.pyplot as plt
import seaborn as sns

# Carregar dados com nomes dos compostos
df = pd.read_csv('fragments_export_com_nomes.csv')

# Verificar valores ausentes
print(df.isnull().sum())

# Remover compostos com menos de 3 amostras
counts = df['compound_id'].value_counts()
valid_ids = counts[counts >= 3].index
df = df[df['compound_id'].isin(valid_ids)]

# Salvar o dicionário de nomes
nomes = df[['compound_id', 'compound_name']].drop_duplicates()
nomes.to_csv('dicionario_nomes.csv', index=False)

# Separar features e rótulos
X = df[['fragment_mz', 'fragment_intensity']]
y = df['compound_id']

# Normalizar
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Dividir treino/teste
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# Treinar modelo
model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)

# Avaliação
y_pred = model.predict(X_test)
print("\nAcurácia:", accuracy_score(y_test, y_pred))
print("\nRelatório:\n", classification_report(y_test, y_pred))

# Salvar modelo e scaler
joblib.dump(model, 'modelo_composto.pkl')
joblib.dump(scaler, 'scaler.pkl')


