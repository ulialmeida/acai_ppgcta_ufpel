"""marcar_colunas_existentes_como_aplicadas

Revision ID: 0662647d5421
Revises: b66cb562d919
Create Date: 2025-04-14 15:55:51.537672

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '0662647d5421'
down_revision = 'b66cb562d919'
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
