"""merge branches

Revision ID: aff338fc8075
Revises: 4457f28150d0, 73b2154c72d8
Create Date: 2025-04-14 08:10:17.967833

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'aff338fc8075'
down_revision = ('4457f28150d0', '73b2154c72d8')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
